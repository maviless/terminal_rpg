package menu.option;

import java.util.ArrayList;


public class OptionFactory {
    ArrayList<Option> options = new ArrayList<Option>();

    public OptionFactory() {
        OptionStartGame optStartGame = new OptionStartGame();
        options.add(optStartGame);

        OptionAbout optAbout = new OptionAbout();
        options.add(optAbout);

        OptionExit optExit = new OptionExit();
        options.add(optExit);

        OptionBackToStartMenu optionBackToStartMenu = new OptionBackToStartMenu();
        options.add(optionBackToStartMenu);
        // backToStartMenu

        OptionTravel optionTravel = new OptionTravel();
        options.add(optionTravel);
        
        OptionGoToMarket optionMarket = new OptionGoToMarket();
        options.add(optionMarket);

        OptionSearchEnemy optionSearchEnemy = new OptionSearchEnemy();
        options.add(optionSearchEnemy);
        
        OptionInventory optionInventory = new OptionInventory();
        options.add(optionInventory);

        OptionRegionCemitery optionRegionCemitery = new OptionRegionCemitery();
        options.add(optionRegionCemitery);
        
        OptionRegionCity optionRegionCity = new OptionRegionCity();
        options.add(optionRegionCity);
        
        OptionRegionDungeon optionRegionDungeon = new OptionRegionDungeon();
        options.add(optionRegionDungeon);
        
        OptionRegionForest optionRegionForest = new OptionRegionForest();
        options.add(optionRegionForest);
        
        OptionRegionMountain optionRegionMountain = new OptionRegionMountain();
        options.add(optionRegionMountain);
        
        OptionBackToStandardMenu optionBackToStandardMenu = new OptionBackToStandardMenu();
        options.add(optionBackToStandardMenu);

        OptionBuyPotion optionBuyPotion = new OptionBuyPotion();
        options.add(optionBuyPotion);

        OptionAttack optionAttack = new OptionAttack();
        options.add(optionAttack);

        OptionPotions optionPotions = new OptionPotions();
        options.add(optionPotions);
        
        OptionBoss optionBoss = new OptionBoss();
        options.add(optionBoss);

        OptionUsePotion1 optionUsePotion1 = new OptionUsePotion1();
        options.add(optionUsePotion1);

        OptionUsePotion2 optionUsePotion2 = new OptionUsePotion2();
        options.add(optionUsePotion2);

        OptionUsePotion3 optionUsePotion3 = new OptionUsePotion3();
        options.add(optionUsePotion3);

        OptionUsePotion4 optionUsePotion4 = new OptionUsePotion4();
        options.add(optionUsePotion4);
        
        OptionBackToBattle optionBackToBattle = new OptionBackToBattle();
        options.add(optionBackToBattle);

        OptionRun optionRun = new OptionRun();
        options.add(optionRun);

        OptionContinue optionContinue = new OptionContinue();
        options.add(optionContinue);
    }

    public Option getOption(String name) {
        for (Option opt : this.options) {
            if(name.equals(opt.name)) {
                return opt;
            }
        }
        System.err.println("You tried to get an option that do not exist :/" );
        return null;
    }
}
