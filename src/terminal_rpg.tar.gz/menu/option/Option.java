package menu.option;

public abstract class Option {
    public String label;
    public String name;
    public abstract void execute();
}
